package com.example.flutter_storyline

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
